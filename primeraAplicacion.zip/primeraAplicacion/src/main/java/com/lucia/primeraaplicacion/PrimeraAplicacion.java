/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.lucia.primeraaplicacion;

/**
 *
 * @author usuario
 */
public class PrimeraAplicacion {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
